#include "dictionary.h"

Dictionary::Dictionary(){
};


int Dictionary::hashValue(char key[]){
    int hashValue = 0;
    // compute hash
    return hashValue;
}

int Dictionary::findFreeIndex(char key[]){
    return -1;
}

struct Entry* Dictionary::get(char key[]){
    return NULL;
}

bool Dictionary::put(Entry e) {
    return false; // Dummy return
}

bool Dictionary::remove(char key[]){
    return false; // Dummy return
}
